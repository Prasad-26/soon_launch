<?php 
 include("header.php");
 include("common/auth_session.php");
 require('common/db.php');

    //$userid=$_GET['uid'];

    if(isset($_POST['submit1'])){
    
      $uid = $_POST['uid'];
      $lodging_bills = $_POST['lodging_bills'];
      print_r($_POST);

      $fileName = $lodging_bills;       
      $filePath = './user/userlodgingbills/'.$fileName ; 

    if(!empty($fileName) && file_exists($filePath))
    { 
        // Define headers         
        header("Cache-Control: public"); 
        header("Content-Description: File Transfer"); 
        header("Content-Disposition: attachment;filename=$fileName"); 
        header("Content-Type: application/octet-stream"); 
        header("Content-Transfer-Encoding: binary"); 
        ob_clean();
        flush();
        // Read the file 
        readfile($filePath); 
        exit; 
    }
   if(empty($fileName))
   {
    echo "<script>alert('File does not exist!');
    window.location.href = 'manage_user.php';
    </script>";
   
   }
    }

    
    if(isset($_POST['submit2'])){
    
    
      $tickets_document = $_POST['tickets_document'];
      print_r($_POST);

      $fileName1 = $tickets_document; 
      $filePath1 = './user/usertickets/'.$fileName1 ; 

       if(!empty($fileName1) && file_exists($filePath1)){ 
        // Define headers 
        
        header("Cache-Control: public"); 
        header("Content-Description: File Transfer"); 
        header("Content-Disposition: attachment;filename=$fileName1"); 
        header("Content-Type: application/octet-stream"); 
        header("Content-Transfer-Encoding: binary"); 
        ob_clean();
        flush();
        // Read the file 
        readfile($filePath1); 
        exit; 
    }
    if(empty($fileName))
    {
     echo "<script>alert('File does not exist!');
     window.location.href = 'manage_user.php';
     </script>";
    
    }

    }

    
    if(isset($_POST['submit3'])){
      print_r($_POST);

      $document_name = $_POST['document_name'];
    
      $fileName2 = $document_name; 
      $filePath2 = './user/userbillsubmitted/'.$fileName2 ; 
 
    if(!empty($fileName2) && file_exists($filePath2))
    { 
        // Define headers 
        header("Cache-Control: public"); 
        header("Content-Description: File Transfer"); 
        header("Content-Disposition: attachment;filename=$fileName2"); 
        header("Content-Type: application/octet-stream"); 
        header("Content-Transfer-Encoding: binary"); 
        ob_clean();
        flush();
        // Read the file 
        readfile($filePath2); 
        exit; 
    }
    if(empty($fileName))
    {
     echo "<script>alert('File does not exist!');
     window.location.href = 'manage_user.php';
     </script>";
    
    }
    }

 
 
    // $dquery=mysqli_query($con,"select document_name from travel_data where tid='$userid'");    
    // while($dresult=mysqli_fetch_assoc($dquery))
    // {
    // $fdocname=$dresult['document_name']; 
    // }

    //  // Define file name and path 
    //   $fileName = $$lodging_bills;       
    //   $filePath = './user/userbillsubmitted/'.$fileName ; 

    // if(!empty($fileName) && file_exists($filePath))
    // { 
    //     // Define headers         
    //     header("Cache-Control: public"); 
    //     header("Content-Description: File Transfer"); 
    //     header("Content-Disposition: attachment;filename=$fileName"); 
    //     header("Content-Type: application/octet-stream"); 
    //     header("Content-Transfer-Encoding: binary"); 
    //     ob_clean();
    //     flush();
    //     // Read the file 
    //     readfile($filePath); 
    //     exit; 
    // }
  

    // $dquery1=mysqli_query($con,"select lodging_bills from travel_data where tid='$userid'");    
    // while($dresult1=mysqli_fetch_assoc($dquery1))
    // {
    // $fdocname1=$dresult1['lodging_bills']; 
    // } 

    // // Define file name and path 
    //   $fileName1 = $fdocname1; 
    //   $filePath1 = './user/userlodgingbills/'.$fileName1 ; 
 
    // if(!empty($fileName1) && file_exists($filePath1)){ 
    //     // Define headers 
        
    //     header("Cache-Control: public"); 
    //     header("Content-Description: File Transfer"); 
    //     header("Content-Disposition: attachment;filename=$fileName1"); 
    //     header("Content-Type: application/octet-stream"); 
    //     header("Content-Transfer-Encoding: binary"); 
    //     ob_clean();
    //     flush();
    //     // Read the file 
    //     readfile($filePath1); 
    //     exit; 
    // }

    // $dquery2=mysqli_query($con,"select tickets_document from travel_data where tid='$userid'");    
    // while($dresult2=mysqli_fetch_assoc($dquery2))
    // {
    // $fdocname2=$dresult2['tickets_document']; 
    // } 

    // // Define file name and path 
    //   $fileName2 = $fdocname2; 
    //   $filePath2 = './user/usertickets/'.$fileName2 ; 
 
    // if(!empty($fileName2) && file_exists($filePath2))
    // { 
    //     // Define headers 
    //     header("Cache-Control: public"); 
    //     header("Content-Description: File Transfer"); 
    //     header("Content-Disposition: attachment;filename=$fileName2"); 
    //     header("Content-Type: application/octet-stream"); 
    //     header("Content-Transfer-Encoding: binary"); 
    //     ob_clean();
    //     flush();
    //     // Read the file 
    //     readfile($filePath2); 
    //     exit; 
    // }
   

?>