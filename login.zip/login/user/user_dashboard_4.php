<html>
<head>
	<meta charset="utf-8">
	<title>Wizard-v10</title>
	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- Font-->
	<link rel="stylesheet" type="text/css" href="css/montserrat-font.css">
	<link rel="stylesheet" type="text/css" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
	<!-- Main Style Css -->
    <link rel="stylesheet" href="css/style.css"/>
</head>
<body>
<script type="text/javascript" src="condition.js"></script>
<link rel="icon" href="fevicon.png" />

<?php
//include auth_session.php file on all user panel pages
include("header.php");
include("../common/auth_session.php");
require('../common/db.php');



$username = $_SESSION['username'];



if (isset($_POST['submit'])) {


  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $designation = $_POST['designation'];
  $branch = $_POST['branch'];
  $fromSation = $_POST['fromSation'];
  $toSataion = $_POST['toSataion'];
  $city = $_POST['city'];
  $Tod = $_POST['Tod'];
  $Toa = $_POST['Toa'];
  $daysOfTravel = $_POST['daysOfTravel'];
  $kmOfTravel = $_POST['kmOfTravel'];
  $daradio = $_POST['daoptradio'];
  $da45 = $_POST['da45'];
  $da5 = $_POST['da5'];
  $da6 = $_POST['da6'];
  $lcradio = $_POST['lcoptradio'];
  $lc45 = $_POST['lc45'];
  $lc5 = $_POST['lc5'];
  $lc6 = $_POST['lc6'];
  $ccradio = $_POST['ccoptradio'];
  $cc4 = $_POST['cc4'];
  $cc5 = $_POST['cc5'];
  $cc6 = $_POST['cc6'];
  $ttradio = $_POST['ticketoptradio'];
  $tt4 = $_POST['tt4'];
  $tt5 = $_POST['tt5'];
  $ttl = $_POST['ttl'];
  $remark = $_POST['remark'];
  $cdac = $_POST['cdac'];
  $clc = $_POST['clc'];
  $ccc = $_POST['ccc'];

//second part variables declaration

  $city1 = $_POST['city1'];
  $Tod1 = $_POST['Tod1'];
  $Toa1 = $_POST['Toa1'];
  $fromSation1 = $_POST['fromSation1'];
  $toSataion1 = $_POST['toSataion1'];
  $daysOfTravel1 = $_POST['daysOfTravel1'];
  $kmOfTravel1 = $_POST['kmOfTravel1'];
  $daradio1 = $_POST['daoptradio1'];
  $da451 = $_POST['da451'];
  $da51 = $_POST['da51'];
  $da61 = $_POST['da61'];
  $lcradio1 = $_POST['lcoptradio1'];
  $lc451 = $_POST['lc451'];
  $lc51 = $_POST['lc51'];
  $lc61 = $_POST['lc61'];
  $ccradio1 = $_POST['ccoptradio1'];
  $cc41 = $_POST['cc41'];
  $cc51 = $_POST['cc51'];
  $cc61 = $_POST['cc61'];
  $ttradio1 = $_POST['ticketoptradio1'];
  $tt41 = $_POST['tt41'];
  $tt51 = $_POST['tt51'];
  $cdac1 = $_POST['cdac1'];
  $clc1 = $_POST['clc1'];
  $ccc1 = $_POST['ccc1'];


  $fnam2 = $_FILES['fileUpload']['name']; //lodging bills is fileToUpload
  // $application_date=now();
  // $fileUpload = $_POST['fileUpload'];


  //echo print_r($_POST);
  if ($ttradio == 'Yes') {
    $my_folder = "usertickets/";
    $uploadOk = true;
    $FileType = pathinfo($target_file, PATHINFO_EXTENSION);
    // Check if file already exists
    if (file_exists($my_folder . $_FILES['fileToUpload']['name'])) {
      echo '<script>alert("SAME FILE NAME ALREADY EXIST!. KINDLY CHANGE FILE NAME & FILL FORM AGAIN.")</script>';
      $uploadOk = false;
      header("Refresh:0;url=user_dashboard.php");
      exit();
    } else if ($uploadOk !== false) {
      move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $my_folder . $_FILES['fileToUpload']['name']);
      $fnam1 = $_FILES['fileToUpload']['name'];
      echo '<script>Received file</script>';

      // mysqli_query($con, $query);
    }
  }

  if ($lcradio == 'Yes') {
    $my_folder = "userlodgingbills/";
    $uploadOk = true;
    $FileType = pathinfo($target_file, PATHINFO_EXTENSION);
    // Check if file already exists
    if (file_exists($my_folder . $_FILES['fileUpload']['name'])) {
      echo '<script>alert("SAME FILE NAME ALREADY EXIST!. KINDLY CHANGE FILE NAME & FILL FORM AGAIN.")</script>';
      $uploadOk = false;
      header("Refresh:0;url=user_dashboard.php");
      exit();
    } else if ($uploadOk !== false) {
      move_uploaded_file($_FILES['fileUpload']['tmp_name'], $my_folder . $_FILES['fileUpload']['name']);
      $fnam2 = $_FILES['fileUpload']['name'];
      echo '<script>Received file</script>';

      // mysqli_query($con, $query);
    }
  }


  $query = "insert into travel_data(username,first_name,last_name,designation,branch,from_station,to_station,city,max_da,max_lc,max_cc,departure_time,arrival_time,
days_of_travel,Km_of_travel,da,da_rate,da_days,da_charges,lc,lc_rate,lc_days,lc_charges,cc,cc_rate,cc_days,cc_charges,ticket,totalno_ticket,
totalamount_ticket,ttl,lodging_bills,tickets_document,Remark,status,application_date,rcity,rdeparture_time,rarrival_time,rfrom_station,rto_station,
rdays_of_travel,rkm_of_travel,rda,rda_rate,rda_days,rda_charges,rlc,rlc_rate,rlc_days,rlc_charges,rcc,rcc_rate,rcc_days,rcc_charges,rticket,rtotalno_ticket,rtotalamount_ticket) 

values('$username','$fname','$lname','$designation','$branch','$fromSation','$toSataion','$city','$cdac','$clc','$ccc','$Tod','$Toa','$daysOfTravel','$kmOfTravel','$daradio',
'$da45','$da5','$da6','$lcradio','$lc45','$lc5','$lc6','$ccradio','$cc4','$cc5','$cc6','$ttradio','$tt4','$tt5','$ttl','$fnam2','$fnam1','$remark','In Process',now(),
'$city1','$Tod1','$Toa1','$fromSation1','$toSataion1','$daysOfTravel1','$kmOfTravel1','$daradio1','$da451','$da51','$da61','$lcradio1','$lc451','$lc51','$lc61','$ccradio1','$cc41','$cc51','$cc61',
'$ttradio1','$tt41','$tt51')";

  if (mysqli_query($con, $query)) {
    echo '<script>alert("Now,upload manager approved TA bill");</script>';
    header("Location:manage_user.php");
  } else {
    echo "Error: " . $query . "<br>" . mysqli_error($con);
  }



  // $result2=mysqli_query($con,"update travel_data set lodging_bills='$fnam2' ");

  // header("Location:manage_user.php");


}


?>
<br>
<div class="container" style="border:1px solid black; padding:15px; background-color:#fff; border-radius:5px;">
<br>
 <form method="POST" action="#" enctype="multipart/form-data">
    <div class="row">
       <div class="col">
          <label for="exampleFormControlInput1" class="form-label">First Name</label>
          <input type="text" class="form-control" style="text-transform: capitalize;" name="fname" placeholder="First Name" aria-label="First name" required>
        </div>
        <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Last Name</label>
          <input type="text" class="form-control" style="text-transform: capitalize;" name="lname" placeholder="Last Name" aria-label="First name" required>
        </div>
        <div class="col">
          <label for="branch" class="form-label">Select your branch</label>
          <select class="form-select" id="branch" aria-label="First Name" name='branch' required>
            <option value="">Select Branch</option>
            <?php
            $sql = mysqli_query($con, "SELECT * From branches");
            $row = mysqli_num_rows($sql);
            while ($row = mysqli_fetch_array($sql)) {
              echo "<option value='" . $row['br_id'] . " " . $row['br_name'] . "'>" . $row['br_id'] . " " . $row['br_name'] . "</option>";
            }
            ?>
          </select>
        </div>
        <div class="col">
          <label for="desig" class="form-label">Designation</label>
          <select class="form-select" id="desig" aria-label="First Name" name="designation" onChange="myFunction2()" required>
            <option value="$designation">Select your designation</option>
            <?php
            $sql = mysqli_query($con, "SELECT * From designation");
            $row = mysqli_num_rows($sql);
            while ($row = mysqli_fetch_array($sql)) {
              echo "<option value='" . $row['designation_name'] . "'>" . $row['designation_name'] . "</option>";
            }
            ?>
          </select>
        </div>
        <br><br>
    </div>
     <!-- Calculate TA Bill -->
     <div class="page-content" >
		<div class="wizard-v10-content">
			<div class="wizard-form">
				<div class="wizard-header">
					<h3>Fill below form</h3>
				</div>
		        <form class="form-register" action="#" method="post">
		        	<div id="form-total">
		        		<!-- SECTION 1 -->
			            <h2>1</h2>
			            <section>
			                <div class="inner">
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<label for="first-name">First Name</label>
										<input type="text" class="form-control" id="first-name" name="first-name">
									</div>
								</div>
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<label for="last-name">Last Name</label>
										<input type="text" class="form-control" id="last-name" name="last-name">
									</div>
								</div>
							</div>
			            </section>
						<!-- SECTION 2 -->
			            <h2>2</h2>
			            <section>
			                <div class="inner">
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<label for="email">Email Address</label>
										<input type="email" class="form-control" id="email" name="email" pattern="[^@]+@[^@]+.[a-zA-Z]{2,6}">
									</div>
								</div>
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<label for="password">Password</label>
										<input type="password" class="form-control" id="password" name="password">
									</div>
								</div>
							</div>
			            </section>
			            <!-- SECTION 3 -->
			            <h2>3</h2>
			            <section>
			                <div class="inner">
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<label for="subject">Subject</label>
										<select name="subject" id="subject" class="form-control">
											<option value="" disabled selected>Your Subject</option>
											<option value="Finance">Finance</option>
											<option value="Marketing">Marketing</option>
											<option value="IT Support">IT Support</option>
										</select>
										<span class="select-btn">
											<i class="zmdi zmdi-chevron-down"></i>
										</span>
									</div>
								</div>
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<label for="comment">Comment</label>
										<input type="text" name="comment" class="form-control" id="comment">
									</div>
								</div>
							</div>
			            </section>
		        	</div>
		        </form>
			</div>
		</div>
	</div>
 </form> 
</div>
 


<!-- Java Script Get Started From here -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script> -->

<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/jquery.steps.js"></script>
	<script src="js/main.js"></script>

<script>
$(document).ready(function(){
var i=1;
$('#add').click(function(){
i++;
$('#dynamic_field').append('<tr id="row1'+i+'"><td><input type="text" name="skill[]" placeholder="Enter your Skill" class="form-control name_list" /></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></tr>');
});
	
$(document).on('click', '.btn_remove', function(){
var button_id = $(this).attr("id"); 
$('#row1'+button_id+'').remove();
});
});
</script>

<script>
  function dashow1() {

    // document.getElementById('da45').value =null;
    document.getElementById("da5").value = null;
    document.getElementById("da6").value = null;
    document.getElementById('da1').style.display = 'none';
    document.getElementById('da2').style.display = 'none';
    document.getElementById('da3').style.display = 'none';
    document.getElementById('da45').required = false;
    document.getElementById("da5").required = false;
    document.getElementById("da6").required = false;

  }

  function dashow2() {
    document.getElementById('da1').style.display = 'block';
    document.getElementById('da2').style.display = 'block';
    document.getElementById('da3').style.display = 'block';
    document.getElementById('da45').required = true;
    document.getElementById("da5").required = true;
    document.getElementById("da6").required = true;

  }

  function dashow3() {

// document.getElementById('da45').value =null;
document.getElementById("da51").value = null;
document.getElementById("da61").value = null;
document.getElementById('da11').style.display = 'none';
document.getElementById('da21').style.display = 'none';
document.getElementById('da31').style.display = 'none';
document.getElementById('da451').required = false;
document.getElementById("da51").required = false;
document.getElementById("da61").required = false;

}
function dashow4() {
   document.getElementById('da11').style.display = 'block';
    document.getElementById('da21').style.display = 'block';
    document.getElementById('da31').style.display = 'block';
    document.getElementById('da451').required = true;
    document.getElementById("da51").required = true;
    document.getElementById("da61").required = true;


}

  function lcshow1() {
    // document.getElementById("lc45").value =null;
    document.getElementById("lc5").value = null;
    document.getElementById("lc6").value = null;

    document.getElementById('lc1').style.display = 'none';
    document.getElementById('lc2').style.display = 'none';
    document.getElementById('lc3').style.display = 'none';
    
    // document.getElementById("lc45").required = false;
    document.getElementById("lc5").required = false;
    document.getElementById("lc6").required = false;
    // document.getElementById("lc7").required = false;

  }

  function lcshow2() {
    document.getElementById('lc1').style.display = 'block';
    document.getElementById('lc2').style.display = 'block';
    document.getElementById('lc3').style.display = 'block';
    // document.getElementById('lc7').style.display = 'block';
    document.getElementById("lc45").required = true;
    document.getElementById("lc5").required = true;
    document.getElementById("lc6").required = true;
    // document.getElementById("lc7").required = true;

  }
  function lcshow3() {
    // document.getElementById("lc45").value =null;
    document.getElementById("lc51").value = null;
    document.getElementById("lc61").value = null;

    document.getElementById('lc11').style.display = 'none';
    document.getElementById('lc21').style.display = 'none';
    document.getElementById('lc31').style.display = 'none';
    
    // document.getElementById("lc45").required = false;
    document.getElementById("lc51").required = false;
    document.getElementById("lc61").required = false;
    // document.getElementById("lc7").required = false;

  }

  function lcshow4() {
    document.getElementById('lc11').style.display = 'block';
    document.getElementById('lc21').style.display = 'block';
    document.getElementById('lc31').style.display = 'block';
    // document.getElementById('lc7').style.display = 'block';
    document.getElementById("lc451").required = true;
    document.getElementById("lc51").required = true;
    document.getElementById("lc61").required = true;
    // document.getElementById("lc7").required = true;

  }

  function ccshow1() {
    document.getElementById("cc4").value = null;
    document.getElementById("cc5").value = null;
    document.getElementById("cc6").value = null;
    document.getElementById('cc1').style.display = 'none';
    document.getElementById('cc2').style.display = 'none';
    document.getElementById('cc3').style.display = 'none';
    document.getElementById("cc4").required = false;
    document.getElementById("cc5").required = false;
    document.getElementById("cc6").required = false;


  }

  function ccshow2() {
    document.getElementById('cc1').style.display = 'block';
    document.getElementById('cc2').style.display = 'block';
    document.getElementById('cc3').style.display = 'block';
    document.getElementById("cc4").required = true;
    document.getElementById("cc5").required = true;
    document.getElementById("cc6").required = true;
  }
  function ccshow3() {
    document.getElementById("cc41").value = null;
    document.getElementById("cc51").value = null;
    document.getElementById("cc61").value = null;
    document.getElementById('cc11').style.display = 'none';
    document.getElementById('cc21').style.display = 'none';
    document.getElementById('cc31').style.display = 'none';
    document.getElementById("cc41").required = false;
    document.getElementById("cc51").required = false;
    document.getElementById("cc61").required = false;


  }

  function ccshow4() {
    document.getElementById('cc11').style.display = 'block';
    document.getElementById('cc21').style.display = 'block';
    document.getElementById('cc31').style.display = 'block';
    document.getElementById("cc41").required = true;
    document.getElementById("cc51").required = true;
    document.getElementById("cc61").required = true;
  }

  function ticketshow1() {
    document.getElementById("tt4").value = null;
    document.getElementById("tt5").value = null;

    document.getElementById('tt1').style.display = 'none';
    document.getElementById('tt2').style.display = 'none';
    //document.getElementById('tt3').style.display = 'none';
    document.getElementById("tt4").required = false;
    document.getElementById("tt5").required = false;
    document.getElementById("fileToUpload").required = false;
  }

  function ticketshow2() {
    document.getElementById('tt1').style.display = 'block';
    document.getElementById('tt2').style.display = 'block';
    //document.getElementById('tt3').style.display = 'block';
    document.getElementById("tt4").required = true;
    document.getElementById("tt5").required = true;
    document.getElementById("fileToUpload").required = true;
  }

  function ticketshow3() {
    document.getElementById("tt41").value = null;
    document.getElementById("tt51").value = null;

    document.getElementById('tt11').style.display = 'none';
    document.getElementById('tt21').style.display = 'none';
    //document.getElementById('tt3').style.display = 'none';
    document.getElementById("tt41").required = false;
    document.getElementById("tt51").required = false;
    document.getElementById("fileToUpload").required = false;
  }

  function ticketshow4() {
    document.getElementById('tt11').style.display = 'block';
    document.getElementById('tt21').style.display = 'block';
    //document.getElementById('tt3').style.display = 'block';
    document.getElementById("tt41").required = true;
    document.getElementById("tt51").required = true;
    document.getElementById("fileToUpload").required = true;
  }

  function multiply() {
    var val1 = document.getElementById('da45').value;
    var val2 = document.getElementById('da5').value;
    var mul = Number(val1) * Number(val2);
    document.getElementById('da6').value = mul;
  }

  function multiply2() {
    var val1 = document.getElementById('lc45').value;
    var val2 = document.getElementById('lc5').value;
    var mul = Number(val1) * Number(val2);
    document.getElementById('lc6').value = mul;
  }

  function multiply3() {
    var val1 = document.getElementById('cc4').value;
    var val2 = document.getElementById('cc5').value;
    var mul = Number(val1) * Number(val2);
    document.getElementById('cc6').value = mul;
  }
  function multiply4() {
    var val1 = document.getElementById('cc41').value;
    var val2 = document.getElementById('cc51').value;
    var mul = Number(val1) * Number(val2);
    document.getElementById('cc61').value = mul;
  }
  function addn() {
    var val1 = document.getElementById('da6').value;
    var val2 = document.getElementById('lc6').value;
    var val3 = document.getElementById('cc6').value;
    var val4 = document.getElementById('tt5').value;
    var addn = Number(val1) + Number(val2) + Number(val3) + Number(val4);
    document.getElementById('ttl').value = addn;
  }
</script>



<script>
  document.querySelector("#Toa").addEventListener("change", myFunction);

  function myFunction() {

    //value start
    var start = Date.parse($("input#Tod").val()); //get timestamp

    //value end
    var end = Date.parse($("input#Toa").val()); //get timestamp

    totalHours = NaN;

    if (start < end) {
      totalHours = Math.floor((end - start) / 1000 / 60 / 60); //milliseconds: /1000 / 60 / 60

      days = Math.round(totalHours / 24);

    } else {
      alert('End Date of journey should be greater than Start Date !!!!');
    }
    $("#totalhour").val(totalHours);

    $("#daysOfTravel").val(days);


  }
</script>

</body>

</html>