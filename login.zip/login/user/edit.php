
<script type="text/javascript" src="condition.js"></script>
<link rel="icon" href="fevicon.png"/> 
<?php
//include auth_session.php file on all user panel pages
include("header.php");
include("../common/auth_session.php");
require('../common/db.php');


  $username=$_SESSION['username'];


//Code for Updation 
if(isset($_POST['update'])){ 
  
    $fname = $_POST['fname']; 
    $lname = $_POST['lname'];
    $designation=$_POST['designation'];
    $branch = $_POST['branch'];
    $fromSation = $_POST['fromSation'];
    $toSataion = $_POST['toSataion'];
    $city=$_POST['city'];
    $Tod = $_POST['Tod'];
    $Toa = $_POST['Toa'];
    $daysOfTravel = $_POST['daysOfTravel'];
    $kmOfTravel = $_POST['kmOfTravel'];
    $daradio = $_POST['daoptradio'];
    $da4 = $_POST['da4'];
    $da5 = $_POST['da5'];
    $da6 = $_POST['da6'];
    $lcradio = $_POST['lcoptradio'];
    $lc4 = $_POST['lc4'];
    $lc5 = $_POST['lc5'];
    $lc6 = $_POST['lc6'];
    $ccradio = $_POST['ccoptradio'];
    $cc4 = $_POST['cc4'];
    $cc5 = $_POST['cc5'];
    $cc6 = $_POST['cc6'];
    $ttradio = $_POST['ticketoptradio'];
    $tt4 = $_POST['tt4'];
    $tt5 = $_POST['tt5'];
    $ttl = $_POST['ttl'];
    $remark = $_POST['remark'];
    $l_upload = $_POST['fileUpload'];
    $cdac = $_POST['cdac'];
    $clc = $_POST['clc'];
    $ccc = $_POST['ccc'];
   
    $userid=$_GET['uid'];
 

    $msg=mysqli_query($con,"update travel_data set first_name='$fname',last_name='$lname',designation='$designation',branch='$branch',from_station='$fromSation',to_station = '$toSataion',city='$city',departure_time = '$Tod',arrival_time='$Toa',days_of_travel='$daysOfTravel',Km_of_travel='$kmOfTravel',da='$daradio',da_rate='$da4',da_days='$da5',da_charges='$da6',lc='$lcradio',lc_rate='$lc4',lc_days='$lc5',lc_charges='$lc6',cc='$ccradio',cc_rate='$cc4',cc_days='$cc5',cc_charges='$cc6',ticket='$ttradio',totalno_ticket='$tt4',totalamount_ticket='$tt5',ttl='$ttl',Remark='$remark',lodging_bills='$l_upload' where tid='$userid'");
    // echo mysqli_affected_rows($con);
if(mysqli_affected_rows($con)>0)
{   
       echo "<script>alert('Travel Bill updated successfully');</script>";       
       echo "<script type='text/javascript'> document.location = 'manage_user.php'; </script>";
    
}


    $target_path = "usertickets/";
    $target_path = $target_path.basename( $_FILES['fileToUpload']['name']);  
    if(move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $target_path)) 
        {  
          // echo "<script>alert('Travel Bill updated successfully');</script>";        
        } 
    else
       {  
          // echo "Sorry, file not uploaded, please try again!";  
       }
   $fnam1=$_FILES['fileToUpload']['name'];  
   $result1=mysqli_query($con,"update travel_data set tickets_document='$fnam1' where tid='$userid'");

   $target_path1 = "userlodgingbills/";
   $target_path1 = $target_path1.basename( $_FILES['fileUpload']['name']);  

    if(move_uploaded_file($_FILES['fileUpload']['tmp_name'], $target_path1)) 
    {  
       // echo "<script>alert('Travel Bill updated successfully');</script>";
    }  
    else
    {  
       // echo "Sorry, file not uploaded, please try again!";  
    }
    $fnam2=$_FILES['fileUpload']['name'];
    $result2=mysqli_query($con,"update travel_data set lodging_bills='$fnam2' where tid='$userid'");

}

// ----------------------------------------------------------------------------------------------------------------

?>

<?php 
$userid=$_GET['uid'];
$query=mysqli_query($con,"select * from travel_data where tid='$userid'");
while($result=mysqli_fetch_array($query))
{
 if($result['da']=='Yes')
 {
  echo '<style> #da1{display:block;}   #da2{display:block;}   #da3{display:block;}   </style>';
 }
  if($result['da']=='No')
 {
  echo '<style>    #da1{display:none;}   #da2{display:none;}   #da3{display:none;}   </style>';
 }
 if($result['lc']=='Yes')
 {
  echo '<style> #lc1{display:block;}   #lc2{display:block;}   #lc3{display:block;}  #lc7{display:block;} </style>';
 }
  if($result['lc']=='No')
 {
  echo '<style>    #lc1{display:none;}   #lc2{display:none;}   #lc3{display:none;} #lc7{display:none;}  </style>';
 }
  if($result['cc']=='Yes')
 {
  echo '<style> #cc1{display:block;}   #cc2{display:block;}   #cc3{display:block;}   </style>';
 }
  if($result['cc']=='No')
 {
  echo '<style>    #cc1{display:none;}   #cc2{display:none;}   #cc3{display:none;}   </style>';
 }
 if($result['ticket']=='Yes')
 {
  echo '<style> #tt1{display:block;}   #tt2{display:block;}   #tt3{display:block;}   </style>';
 }
  if($result['ticket']=='No')
 {
  echo '<style>    #tt1{display:none;}   #tt2{display:none;}   #tt3{display:none;}   </style>';
 }

?>

<div class="container">
   <div class="form">
      <h5 class="text-center">Update Travel Bill Details</h5>
      <hr>  
       <form method="POST" action="#" enctype="multipart/form-data" style=" 
 background:linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.9)),url('aucb_wm.png') no-repeat;
 background-position: center;
 background-size:55%;">
          <div class="row">
               <div class="col">
                  <label for="exampleFormControlInput1" class="form-label">First Name</label> 
                   <input type="text" class="form-control"  name="fname" style="text-transform: capitalize;" placeholder="First Name" value="<?php echo $result['first_name'];?>" aria-label="First name" required>
             </div>
             <div class="col">
                  <label for="exampleFormControlInput1" class="form-label">Last name</label> 
                   <input type="text" class="form-control"  name="lname" style="text-transform: capitalize;" placeholder="Last Name" value="<?php echo $result['last_name'];?>" aria-label="First name" required>
             </div>
             <div class="col">                          
                <label for="branch" class="form-label">Select your branch</label>
                <select class="form-select" id="branch" aria-label="First Name"  name='branch' >    
                              <option value="<?php echo $result['branch'];?>"><?php echo $result['branch'];?></option>
                                 <?php
                                 $sql = mysqli_query($con, "SELECT * From branches");
                                 $row = mysqli_num_rows($sql);
                                 while ($row = mysqli_fetch_array($sql)){
                                 echo "<option value='" .$row['br_id'] ." ". $row['br_name'] ."'>" .$row['br_id'] ." " .$row['br_name'] ."</option>";
                                 }
                                 ?>
                              </select>
                </div>   
             <div class="col">                          
                <label for="desig" class="form-label">Designation</label>
                <select class="form-select" id="desig" aria-label="First Name" name="designation" onChange="myFunction2()">
                                <option value="<?php echo $result['designation'];?>"><?php echo $result['designation'];?></option>
                                <?php
                                $sql = mysqli_query($con, "SELECT * From designation");
                                $row = mysqli_num_rows($sql);
                                while ($row = mysqli_fetch_array($sql)){
                                echo "<option value='". $row['designation_name'] ."'>" .$row['designation_name'] ."</option>";
                                }
                                ?>
                               </select>
                </div>
                <div class="col">  
                    <label for="city" class="form-label">Travelling City Type</label>
                    <select class="form-select" id="city" aria-label="First Name" name='city' onChange="myFunction2()" >   
                                  <option value="<?php echo $result['city'];?>"><?php echo $result['city'];?></option>
                                    <?php
                                        $sql = mysqli_query($con, "SELECT * From city");
                                        $row = mysqli_num_rows($sql);
                                        while ($row = mysqli_fetch_array($sql)){
                                            echo "<option value='". $row['city_name'] ."'>" .$row['city_name'] ."</option>";
                                           }
                                      ?>
                          </select>
                   </div>
                   </div>



<br>
<hr>

<div class="row">
   <div class="col">
      <label for="exampleFormControlInput1" class="form-label">Max. DA Charges (For 24hrs)</label>
        <input readonly type="number" class="form-control" id="cdac" name="cdac" placeholder="DA Charges"   value="<?php echo $result['max_da'];?>" aria-label="Last name" >
    </div>
    <div class="col">
      <label for="exampleFormControlInput1" class="form-label">Max. Lodging Charges (For 24hrs)</label>
      <input readonly type="number" class="form-control" id="clc" name="clc" placeholder="Lodging Charges"  value="<?php echo $result['max_lc'];?>"  aria-label="Last name" >
   </div>
   <div class="col">
     <label for="exampleFormControlInput1" class="form-label">Max. Conveyance Charges (For 24hrs)</label>
     <input readonly type="number" class="form-control" id="ccc" name="ccc" placeholder="Conveyance Charges"  value="<?php echo $result['max_cc'];?>" aria-label="Last name" >
   </div>
  </div>
  <br>
  <hr>
 
 <div class="row">
     <div class="col">
        <label for="exampleFormControlInput1" class="form-label">From Station</label>
          <input type="text" class="form-control" style="text-transform: capitalize;" name="fromSation" placeholder="From Station" aria-label="Last name" value="<?php echo $result['from_station'];?>" required>
     </div>
     <div class="col">
       <label for="exampleFormControlInput1" class="form-label">To Station</label>
       <input type="text" class="form-control" style="text-transform: capitalize;" name="toSataion" placeholder="To Station" aria-label="Last name" value="<?php echo $result['to_station'];?>" required>
     </div>
     <div class="col">
       <label for="exampleFormControlInput1" class="form-label">Total KMs of Travel</label>
       <input type="number" class="form-control" name="kmOfTravel" placeholder="Total Kilo-Meters of Travel" aria-label="First name" value="<?php echo $result['Km_of_travel'];?>" required>
    </div>  
       <div class="col">
          <label for="exampleFormControlInput1" class="form-label">Start Date of Journey</label>
          <input type="datetime-local" class="form-control" id="Tod" name="Tod" placeholder="Time Of Diparture" aria-label="First name" value="<?php echo $result['departure_time'];?>" required>
       </div>
       <div class="col">
           <label for="exampleFormControlInput1" class="form-label">End Date of Journey</label>
           <input type="datetime-local" class="form-control" id="Toa" name="Toa" placeholder="Time Of Arrival" aria-label="Last name" onChange="myFunction()" value="<?php echo $result['arrival_time'];?>" required>
       </div>
       <div class="col">
           <label for="exampleFormControlInput1" class="form-label">Total Days of Travel</label>
           <input readonly type="number" class="form-control" id="daysOfTravel" name="daysOfTravel" placeholder="Total Days of Travel" aria-label="Last name" value="<?php echo $result['days_of_travel'];?>" required>
       </div>
       </div>
<br>
<hr>
<div class="row">

   <div class="col-3" >
       <p>Do you want to fill DA Charges?</p>
       <input type="radio" class="form-check-input" id="daradio" name="daoptradio" onclick="dashow2();" value="Yes" <?php echo ($result['da']=='Yes')?'checked':''?>  > Yes
       <label class="form-check-label" for="daradio"> </label>
       <input type="radio" class="form-check-input" id="daradio" name="daoptradio"  onclick="dashow1();" value="No" <?php echo ($result['da']=='No')?'checked':'' ?>  > No
       <label class="form-check-label" for="daradio"></label>
   </div>
    <div class="col" id="da1"  >
        <label for="exampleFormControlInput1"  class="form-label">DA Rate:</label>
        <input  type="number" class="form-control" id="da4"  name="da4" placeholder="Amount" aria-label="Last name" onChange="multiply()" value="<?php echo $result['da_rate'];?>">
    </div>
     <div class="col" id="da2"  >
       <label for="exampleFormControlInput1"  class="form-label">No of Days:</label>
       <input  type="number" class="form-control" id="da5"  name="da5" placeholder="Days" aria-label="Last name" onChange="multiply()" value="<?php echo $result['da_days'];?>">
      </div>
     <div class="col" id="da3"  >
       <label for="exampleFormControlInput1"  class="form-label">DA Charges:</label>
       <input readonly type="number" class="form-control" id="da6"  name="da6" placeholder="Total Amount" aria-label="Last name" value="<?php echo $result['da_charges'];?>">
     </div>
</div>

<br>
<hr>
<div class="row">
   <div class="col-3" >
      <p>Do you want to fill Lodging Charges?</p>
      <input type="radio" class="form-check-input" id="lcradio" name="lcoptradio" value="Yes" onclick="lcshow2();" <?php echo ($result['lc']=='Yes')?'checked':''?>> Yes
      <label class="form-check-label" for="lcradio"> </label>
      <input type="radio" class="form-check-input" id="lcradio" name="lcoptradio" value="No"  onclick="lcshow1();" <?php echo ($result['lc']=='No')?'checked':''?>> No
      <label class="form-check-label" for="lcradio"></label>
   </div>
   <div class="col" id="lc1" >
    <label for="exampleFormControlInput1"  class="form-label">Lodging Rate:</label>
    <input  type="number" class="form-control" id="lc4"  name="lc4" placeholder="Amount" aria-label="Last name" onChange="multiply2()" value="<?php echo $result['lc_rate'];?>">
  </div>
   <div class="col" id="lc2"  >
      <label for="exampleFormControlInput1"  class="form-label">No of Days:</label>
      <input  type="number" class="form-control" id="lc5"  name="lc5" placeholder="Days" aria-label="Last name" onChange="multiply2()" value="<?php echo $result['lc_days'];?>">
   </div>
   <div class="col" id="lc3"  >
      <label for="exampleFormControlInput1"  class="form-label">Lodging Charges:</label>
      <input readonly type="number" class="form-control" id="lc6"  name="lc6" placeholder="Total Amount" aria-label="Last name" value="<?php echo $result['lc_charges'];?>">
   </div>
    <div class="col" id="lc7" >
      <label for="img">Upload Lodging Bills Here</label> 
      <input  type="file" id="fileUpload" name="fileUpload" value="<?php echo $result['lodging_bills'];?>"/>
   </div>
</div>

<br>
<hr>
<div class="row">
     <div class="col-3" >
     <p>Do you want to fill Conveyance charges?</p>
     <input type="radio" class="form-check-input" id="ccradio" name="ccoptradio" value="Yes" onclick="ccshow2();" <?php echo ($result['cc']=='Yes')?'checked':''?> > Yes
     <label class="form-check-label" for="ccradio"> </label>
     <input type="radio" class="form-check-input" id="ccradio" name="ccoptradio" value="No"  onclick="ccshow1();" <?php echo ($result['cc']=='No')?'checked':''?>> No
     <label class="form-check-label" for="ccradio"></label>
</div>
<div class="col" id="cc1" >
   <label for="exampleFormControlInput1"  class="form-label">Conveyance Rate:</label>
   <input  type="number" class="form-control" id="cc4"  name="cc4" placeholder="Amount" aria-label="Last name" onChange="multiply3()" value="<?php echo $result['cc_rate'];?>">
</div>
<div class="col" id="cc2"  >
   <label for="exampleFormControlInput1"  class="form-label">No of Days:</label>
   <input  type="number" class="form-control" id="cc5"  name="cc5" placeholder="Days" aria-label="Last name" onChange="multiply3()" value="<?php echo $result['cc_days'];?>">
</div>
<div class="col" id="cc3" >
   <label for="exampleFormControlInput1"  class="form-label">Conveyance Charges:</label>
   <input readonly type="number" class="form-control" id="cc6"  name="cc6" placeholder="Total Amount"  aria-label="Last name" value="<?php echo $result['cc_charges'];?>">
 </div>

</div>

<br>

<hr>
<div class="row">

<div class="col-3" >
<p>Do you want to fill Railway/Bus ticket charges?</p>
<input type="radio" class="form-check-input" id="ticketradio" name="ticketoptradio" value="Yes" onclick="ticketshow2();" <?php echo ($result['ticket']=='Yes')?'checked':''?> > Yes
<label class="form-check-label" for="ticketradio"> </label>
<input type="radio" class="form-check-input" id="ticketradio" name="ticketoptradio" value="No"  onclick="ticketshow1();" <?php echo ($result['ticket']=='No')?'checked':''?>> No
<label class="form-check-label" for="ticketradio"></label>
</div>


<div class="col" id="tt1" >
<label for="exampleFormControlInput1"  class="form-label">Total no of tickets</label>
<input  type="number" class="form-control" id="tt4"  name="tt4" placeholder="Total no of tickets" aria-label="Last name"  value="<?php echo $result['totalno_ticket'];?>">
</div>

<div class="col" id="tt2"  >
<label for="exampleFormControlInput1"  class="form-label">Total ticket amount</label>
<input  type="number" class="form-control" id="tt5"  name="tt5" placeholder="Total Amount"  aria-label="Last name" value="<?php echo $result['totalamount_ticket'];?>">
</div>

<div class="col" id="tt3"  >
<label for="img">Upload Tickets Here</label> <br>
<input  type="file" id="fileToUpload" name="fileToUpload"  value="<?php echo $result['tickets_document'];?>"/>
</div>

</div>
<br>
<hr>
<div class="row" >

<div class="col-4">
<label for="exampleFormControlInput1" class="form-label" style="display:block;">Click below button to get total amount:  </label>
<input type="button" value="Calculate Total" onclick="addn()" />
</div>

<div class="col-4">
<label for="exampleFormControlInput1" class="form-label">Total Amount</label>
<input readonly type="text" class="form-control" id="ttl" name="ttl"  placeholder="Total" aria-label="First name" value="<?php echo $result['ttl'];?>" required>
</div>
<div class="col-4">
<label for="exampleFormControlInput1" class="form-label">Remark/Purpose</label>
<textarea  class="form-control" rows="3" placeholder="Remark (if any)" style="text-transform: capitalize;" name="remark" aria-label="Last name"  value="<?php echo $result['Remark'];?>" ><?php echo $result['Remark'];?></textarea>

</div>
</div>

<br>

   

<!-- Calculate TA Bill not needed on user side -->

<br>
<center>
  
<a class="btn btn-primary" href="manage_user.php"  id="btn1" >Back</a>     

<button class="btn btn-primary" type="submit" name="update" id="btn" >Update Data</button>

</center>

</form> 
<?php } ?>
</div>
</div>


   <!-- Java Script Get Started From here -->
   
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

   <script>

    function dashow1(){
     
      document.getElementById('da1').style.display ='none';        
      document.getElementById('da2').style.display ='none';     
      document.getElementById('da3').style.display ='none';
      document.getElementById("da4").value =null;
      document.getElementById("da5").value =null;
      document.getElementById("da6").value =null;
      
    }
     
        function dashow2(){
      document.getElementById('da1').style.display = 'block';
      document.getElementById('da2').style.display = 'block';   
      document.getElementById('da3').style.display = 'block';    
      
    }
    function lcshow1(){
      document.getElementById("lc4").value =null;
      document.getElementById("lc5").value =null;
      document.getElementById("lc6").value =null;
      document.getElementById('lc1').style.display ='none';
      document.getElementById('lc2').style.display ='none';
      document.getElementById('lc3').style.display ='none';
      document.getElementById('lc7').style.display ='none';
     
     }
    
    function lcshow2(){
      document.getElementById('lc1').style.display = 'block';
      document.getElementById('lc2').style.display = 'block';   
      document.getElementById('lc3').style.display = 'block';
      document.getElementById('lc7').style.display = 'block';    
    }
    function ccshow1(){
      document.getElementById("cc4").value =null;
      document.getElementById("cc5").value =null;
      document.getElementById("cc6").value =null;
      document.getElementById('cc1').style.display ='none';
      document.getElementById('cc2').style.display ='none';
      document.getElementById('cc3').style.display ='none';
  
     }
    
    function ccshow2(){
      document.getElementById('cc1').style.display = 'block';
      document.getElementById('cc2').style.display = 'block';   
      document.getElementById('cc3').style.display = 'block';    
    }
    function ticketshow1(){
      document.getElementById("tt4").value =null;
      document.getElementById("tt5").value =null;
      document.getElementById("fileToUpload").value =null;
      document.getElementById('tt1').style.display ='none';
      document.getElementById('tt2').style.display ='none';
      document.getElementById('tt3').style.display ='none';
     }
    
    function ticketshow2(){
      document.getElementById('tt1').style.display = 'block';
      document.getElementById('tt2').style.display = 'block';   
      document.getElementById('tt3').style.display = 'block';    
    }
    function multiply()
    {      
      var val1 = document.getElementById('da4').value;      
      var val2 = document.getElementById('da5').value;
      var mul = Number(val1) * Number(val2);       
      document.getElementById('da6').value=mul;
    }
    function multiply2()
    {      
      var val1 = document.getElementById('lc4').value;      
      var val2 = document.getElementById('lc5').value;
      var mul = Number(val1) * Number(val2);       
      document.getElementById('lc6').value=mul;
    }
    function multiply3()
    {      
      var val1 = document.getElementById('cc4').value;      
      var val2 = document.getElementById('cc5').value;
      var mul = Number(val1) * Number(val2);  
      document.getElementById('cc6').value=mul;
    }
    function addn(){ 
      var val1 = document.getElementById('da6').value;      
      var val2 = document.getElementById('lc6').value;
      var val3 = document.getElementById('cc6').value;
      var val4 = document.getElementById('tt5').value;
      var addn = Number(val1) + Number(val2)+ Number(val3)+Number(val4);       
      document.getElementById('ttl').value=addn;
    }
   </script>

   <script>
   function chargesTotal(){
       var value_1 = document.getElementById('dac').value;
       var value_2 = document.getElementById('lc').value;
       var value_3 = document.getElementById('tf').value;
       var value_4 = document.getElementById('cc').value;
       var total = Number(value_1) + Number(value_2) + Number(value_3) + Number(value_4);
       var displaySum = document.getElementById('total');
           displaySum.value = total;
       //alert(total);
    }
 </script>

<script>

document.querySelector("#Toa").addEventListener("change", myFunction);

function myFunction() {

  //value start
   var start = Date.parse($("input#Tod").val()); //get timestamp

  //value end
  var end = Date.parse($("input#Toa").val()); //get timestamp

  totalHours = NaN;
 
  if (start < end) {
   totalHours = Math.floor((end - start) / 1000 / 60 / 60); //milliseconds: /1000 / 60 / 60
   
    days = Math.round(totalHours/24);
    
  }

 $("#totalhour").val(totalHours);
  
 $("#daysOfTravel").val(days);
 
       
}

</script>

<script>

// function myFunction2()
// {
 
//   var design = document.getElementById("desig").value;

//   var city = document.getElementById('city').value;

//   //var tim = document.getElementById('totalhour').value;
     
  
//   if(design=="Dy. CEO/Chief Manager" && city == "Metro City")
//     {
//       var tt = 6000;
//       var da = (25/100) * tt;
//       var lc = (60/100) * tt;
//       var cc = (15/100) * tt;

//       // var calculated= da+lc+cc;
//       // var displaycalc = document.getElementById('ata');
//       // displaycalc.value = calculated;
//       document.getElementById('cdac').value = da;
//       document.getElementById('clc').value = lc;
//       document.getElementById('ccc').value = cc;
     
//     }
//   }

  function myFunction1()
{
  var e = document.getElementById("desig").value;

  var city = document.getElementById('city').value;

  var tim = document.getElementById('totalhour').value;
     
  
  if(e=="Dy. CEO/Chief Manager" && city == "Metro City")
    {
      var tt = 6000;
      
      if(tim<6)
      {
        
        var da = 0;
        var lc = 0;
        var cc = (15/100) * tt;
        var calculated= da+lc+cc;
       
        var displaycalc = document.getElementById('total');
           displaycalc.value = calculated;

      }
      else if(tim>6 && tim<12)
      {
        var da = (12.5/100) * tt; 
        var lc = (30/100) * tt; 
        var cc = (15/100) *  tt;
        var calculated= da+lc+cc; 
        var displaycalc = document.getElementById('total');
           displaycalc.value = calculated;
      }
      else if(tim>12)
      {
        var da = (25/100) * tt;
        var lc = (60/100) * tt;
        var cc = (15/100) * tt;
        var calculated= da+lc+cc;
        var displaycalc = document.getElementById('total');
           displaycalc.value = calculated;
      }
    }

    // if(desg=="Branch Head" && city == "metro")
    // {
    //   var total = 5000;
      
    //   if(tim < 6)
    //   {
        
    //     var da = 0;
    //     var lc = 0;
    //     var cc = 15% * total;
    //     var calculated= da+lc+cc;
    //     var displaycalc = document.getElementById('total');
    //        displaycalc.value = calculated;

    //   }
    //   elseif(tim>6 && tim<12)
    //   {
    //     var da = 12.5% * total;
    //     var lc = 30% * total;
    //     var cc = 15% * total;
    //     var calculated= da+lc+cc;
    //     var displaycalc = document.getElementById('total');
    //        displaycalc.value = calculated;
    //   }
    //   else(tim>12)
    //   {
    //     var da = 25% * total;
    //     var lc = 60% * total;
    //     var cc = 15% * total;
    //     var calculated= da+lc+cc;
    //     var displaycalc = document.getElementById('total');
    //        displaycalc.value = calculated;
    //   }
    // }
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
