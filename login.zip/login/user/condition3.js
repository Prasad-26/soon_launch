

function myFunction3()
{
  
  var design = document.getElementById("desig").value;

//   var city3 = document.getElementById("city").value;
  
  // var city2 = document.getElementById("city2").value;
  
  var city3 = document.getElementById("city3").value;

  //var tim = document.getElementById('totalhour').value;
     
  
  if(design=="Dy. CEO/Chief Manager" && city3 == "Metro City" )
    {

      var tt = 6000;
      var da = (25/100) * tt;
      var lc = (60/100) * tt;
      var cc = (15/100) * tt;
      

     
      // document.getElementById('cdac').value = da;
      // document.getElementById('clc').value = lc;
      // document.getElementById('ccc').value = cc;
      document.getElementById('da452').value = da;
      document.getElementById('lc452').value = lc;
      // document.getElementById('da4521').value = da;
      // document.getElementById('lc4521').value = lc;
      // document.getElementById('da4522').value = da;
      // document.getElementById('lc4522').value = lc;
      // document.getElementById('da4523').value = da;
      // document.getElementById('lc4523').value = lc;
      
     

      
    }
   

     if(design=="Branch Head" && city3 == "Metro City")
    {
     
      var tt1 = 5000;
      var da1 = (25/100) * tt1;
      var lc1 = (60/100) * tt1;
      var cc1 = (15/100) * tt1;
      var mm1 = (10/100) * tt1;

    
      // document.getElementById('cdac').value = da1;
      // document.getElementById('clc').value = lc1;
      // document.getElementById('ccc').value = cc1;
      document.getElementById('da452').value = da1;
      document.getElementById('lc452').value = lc1;
     
    }
      if(design=="Officer" && city3 == "Metro City")
    {
    
      var tt2 = 4500;
      var da2 = (25/100) * tt2;
      var lc2 = (60/100) * tt2;
      var cc2 = (15/100) * tt2;

 
      // document.getElementById('cdac').value = da2;
      // document.getElementById('clc').value = lc2;
      // document.getElementById('ccc').value = cc2;
      document.getElementById('da452').value = da2;
      document.getElementById('lc452').value = lc2;
     
    }
      if(design=="Executive" && city3 == "Metro City")
    {
   
      var tt3 = 3000;
      var da3 = (25/100) * tt3;
      var lc3 = (60/100) * tt3;
      var cc3 = (15/100) * tt3;

      
      // document.getElementById('cdac').value = da3;
      // document.getElementById('clc').value = lc3;
      // document.getElementById('ccc').value = cc3;
      document.getElementById('da452').value = da3;
      document.getElementById('lc452').value = lc3;
     
    }
      if(design=="Messenger/Driver" && city3 == "Metro City")
    {
    
      var tt4 = 2500;
      var da4 = (25/100) * tt4;
      var lc4 = (60/100) * tt4;
      var cc4 = (15/100) * tt4;

    
      // document.getElementById('cdac').value = da4;
      // document.getElementById('clc').value = lc4;
      // document.getElementById('ccc').value = cc4;
      document.getElementById('da452').value = da4;
      document.getElementById('lc452').value = lc4;
     
    }
    
      if(design=="Dy. CEO/Chief Manager" && city3 == "District Centre")
    {
  
      var tt10 = 2500;
      var da10 = (25/100) * tt10;
      var lc10 = (60/100) * tt10;
      var cc10 = (15/100) * tt10;

     
      // document.getElementById('cdac').value = da10;
      // document.getElementById('clc').value = lc10;
      // document.getElementById('ccc').value = cc10;
      document.getElementById('da452').value = da10;
      document.getElementById('lc452').value = lc10;
     
    }
      if(design=="Branch Head" && city3 == "District Centre")
    {
    
      var tt11 = 2000;
      var da11 = (25/100) * tt11;
      var lc11 = (60/100) * tt11;
      var cc11 = (15/100) * tt11;

     
      // document.getElementById('cdac').value = da11;
      // document.getElementById('clc').value = lc11;
      // document.getElementById('ccc').value = cc11;
      document.getElementById('da452').value = da11;
      document.getElementById('lc452').value = lc11;
    }
      if(design=="Officer" && city3 == "District Centre")
    {
  
      var tt12 = 2000;
      var da12 = (25/100) * tt12;
      var lc12 = (60/100) * tt12;
      var cc12 = (15/100) * tt12;

      
      // document.getElementById('cdac').value = da12;
      // document.getElementById('clc').value = lc12;
      // document.getElementById('ccc').value = cc12;
      document.getElementById('da452').value = da12;
      document.getElementById('lc452').value = lc12;
    }
      if(design=="Executive" && city3 == "District Centre")
    {
   
      var tt13 = 1500;
      var da13 = (25/100) * tt13;
      var lc13 = (60/100) * tt13;
      var cc13 = (15/100) * tt13;

      // var calculated= da+lc+cc;
      // var displaycalc = document.getElementById('ata');
      // displaycalc.value = calculated;
      // document.getElementById('cdac').value = da13;
      // document.getElementById('clc').value = lc13;
      // document.getElementById('ccc').value = cc13;
      document.getElementById('da452').value = da13;
      document.getElementById('lc452').value = lc13;
    }
      if(design=="Messenger/Driver" && city3 == "District Centre")
    {

      var tt14 = 1200;
      var da14 = (25/100) * tt14;
      var lc14 = (60/100) * tt14;
      var cc14 = (15/100) * tt14;

      // var calculated= da+lc+cc;
      // var displaycalc = document.getElementById('ata');
      // displaycalc.value = calculated;
      // document.getElementById('cdac').value = da14;
      // document.getElementById('clc').value = lc14;
      // document.getElementById('ccc').value = cc14;
      document.getElementById('da452').value = da14;
      document.getElementById('lc452').value = lc14;
    }
      if(design=="Dy. CEO/Chief Manager" && city3 == "Taluka and Below Centre")
    {

      var tt15 = 2000;
      var da15 = (25/100) * tt15;
      var lc15 = (60/100) * tt15;
      var cc15 = (15/100) * tt15;
      // document.getElementById('cdac').value = da15;
      // document.getElementById('clc').value = lc15;
      // document.getElementById('ccc').value = cc15;
      document.getElementById('da452').value = da15;
      document.getElementById('lc452').value = lc15;
    }
       if(design=="Branch Head" && city3 == "Taluka and Below Centre")
    {
   
      var tt16 = 1500;
      var da16 = (25/100) * tt16;
      var lc16 = (60/100) * tt16;
      var cc16 = (15/100) * tt16;
      //  document.getElementById('cdac').value = da16;
      // document.getElementById('clc').value = lc16;
      // document.getElementById('ccc').value = cc16;
      document.getElementById('da452').value = da16;
      document.getElementById('lc452').value = lc16;
    }
       if(design=="Officer" && city3 == "Taluka and Below Centre")
    {

      var tt17 = 1500;
      var da17 = (25/100) * tt17;
      var lc17 = (60/100) * tt17;
      var cc17 = (15/100) * tt17;
      //  document.getElementById('cdac').value = da17;
      // document.getElementById('clc').value = lc17;
      // document.getElementById('ccc').value = cc17;
      document.getElementById('da452').value = da17;
      document.getElementById('lc452').value = lc17;
    }
       if(design=="Executive" && city3 == "Taluka and Below Centre")
    {
  
      var tt18 = 1200;
      var da18 = (25/100) * tt18;
      var lc18 = (60/100) * tt18;
      var cc18 = (15/100) * tt18;
      // document.getElementById('cdac').value = da18;
      // document.getElementById('clc').value = lc18;
      // document.getElementById('ccc').value = cc18;
      document.getElementById('da452').value = da18;
      document.getElementById('lc452').value = lc18;
    }

       if(design=="Messenger/Driver" && city3 == "Taluka and Below Centre")
    {
     
      var tt19 = 1000;
      var da19 = (25/100) * tt19;
      var lc19 = (60/100) * tt19;
      var cc19 = (15/100) * tt19;
      // document.getElementById('cdac').value = da19;
      // document.getElementById('clc').value = lc19;
      // document.getElementById('ccc').value = cc19;
      document.getElementById('da452').value = da19;
      document.getElementById('lc452').value = lc19;
    }
    if(design=="Dy. CEO/Chief Manager" && city3 =="Nagpur")
    {
     
      var tt20 = 4000;
      var da20 = (25/100) * tt20;
      var lc20 = (60/100) * tt20;
      var cc20 = (15/100) * tt20;
      // document.getElementById('cdac').value = da20;
      // document.getElementById('clc').value = lc20;
      // document.getElementById('ccc').value = cc20;
      document.getElementById('da452').value = da20;
      document.getElementById('lc452').value = lc20;
    }
    if(design=="Dy. CEO/Chief Manager" && city3 =="Nashik")
    {
   
      var tt20 = 4000;
      var da20 = (25/100) * tt20;
      var lc20 = (60/100) * tt20;
      var cc20 = (15/100) * tt20;
      // document.getElementById('cdac').value = da20;
      // document.getElementById('clc').value = lc20;
      // document.getElementById('ccc').value = cc20;
      document.getElementById('da452').value = da20;
      document.getElementById('lc452').value = lc20;
    }
    if(design=="Dy. CEO/Chief Manager" && city3 =="Aurangabad")
    {
  
      var tt20 = 4000;
      var da20 = (25/100) * tt20;
      var lc20 = (60/100) * tt20;
      var cc20 = (15/100) * tt20;
      // document.getElementById('cdac').value = da20;
      // document.getElementById('clc').value = lc20;
      // document.getElementById('ccc').value = cc20;
      document.getElementById('da452').value = da20;
      document.getElementById('lc452').value = lc20;
    }
    if(design=="Dy. CEO/Chief Manager" && city3 =="Nanded")
    {

      var tt20 = 4000;
      var da20 = (25/100) * tt20;
      var lc20 = (60/100) * tt20;
      var cc20 = (15/100) * tt20;
      // document.getElementById('cdac').value = da20;
      // document.getElementById('clc').value = lc20;
      // document.getElementById('ccc').value = cc20;
      document.getElementById('da452').value = da20;
      document.getElementById('lc452').value = lc20;
    }
    if(design=="Dy. CEO/Chief Manager" && city3 =="Akola")
    {

      var tt20 = 4000;
      var da20 = (25/100) * tt20;
      var lc20 = (60/100) * tt20;
      var cc20 = (15/100) * tt20;
      // document.getElementById('cdac').value = da20;
      // document.getElementById('clc').value = lc20;
      // document.getElementById('ccc').value = cc20;
      document.getElementById('da452').value = da20;
      document.getElementById('lc452').value = lc20;
     }
    if(design=="Dy. CEO/Chief Manager" && city3 =="Amravati")
    {

      var tt20 = 4000;
      var da20 = (25/100) * tt20;
      var lc20 = (60/100) * tt20;
      var cc20 = (15/100) * tt20;
      // document.getElementById('cdac').value = da20;
      // document.getElementById('clc').value = lc20;
      // document.getElementById('ccc').value = cc20;
      document.getElementById('da452').value = da20;
      document.getElementById('lc452').value = lc20;
    }
    if(design=="Dy. CEO/Chief Manager" && city3 =="Indore")
    {
    
      var tt20 = 4000;
      var da20 = (25/100) * tt20;
      var lc20 = (60/100) * tt20;
      var cc20 = (15/100) * tt20;
      // document.getElementById('cdac').value = da20;
      // document.getElementById('clc').value = lc20;
      // document.getElementById('ccc').value = cc20;
      document.getElementById('da452').value = da20;
      document.getElementById('lc452').value = lc20;
    }
    if(design=="Branch Head" && city3 =="Nagpur")
    {
   
      var tt21 = 3000;
      var da21 = (25/100) * tt21;
      var lc21 = (60/100) * tt21;
      var cc21 = (15/100) * tt21;
      // document.getElementById('cdac').value = da21;
      // document.getElementById('clc').value = lc21;
      // document.getElementById('ccc').value = cc21;
      document.getElementById('da452').value = da21;
      document.getElementById('lc452').value = lc21;
     }
     if(design=="Branch Head" && city3 =="Nashik")
     {
   
       var tt21 = 3000;
       var da21 = (25/100) * tt21;
       var lc21 = (60/100) * tt21;
       var cc21 = (15/100) * tt21;
      //  document.getElementById('cdac').value = da21;
      //  document.getElementById('clc').value = lc21;
      //  document.getElementById('ccc').value = cc21;
       document.getElementById('da452').value = da21;
      document.getElementById('lc452').value = lc21;
      }
      if(design=="Branch Head" && city3 =="Aurangabad")
      {

        var tt21 = 3000;
        var da21 = (25/100) * tt21;
        var lc21 = (60/100) * tt21;
        var cc21 = (15/100) * tt21;
        // document.getElementById('cdac').value = da21;
        // document.getElementById('clc').value = lc21;
        // document.getElementById('ccc').value = cc21;
        document.getElementById('da452').value = da21;
      document.getElementById('lc452').value = lc21;
       }
       if(design=="Branch Head" && city3 =="Nanded")
       {
    
         var tt21 = 3000;
         var da21 = (25/100) * tt21;
         var lc21 = (60/100) * tt21;
         var cc21 = (15/100) * tt21;
        //  document.getElementById('cdac').value = da21;
        //  document.getElementById('clc').value = lc21;
        //  document.getElementById('ccc').value = cc21;
         document.getElementById('da452').value = da21;
      document.getElementById('lc452').value = lc21;
        }
        if(design=="Branch Head" && city3 =="Akola")
        {
    
          var tt21 = 3000;
          var da21 = (25/100) * tt21;
          var lc21 = (60/100) * tt21;
          var cc21 = (15/100) * tt21;
          // document.getElementById('cdac').value = da21;
          // document.getElementById('clc').value = lc21;
          // document.getElementById('ccc').value = cc21;
          document.getElementById('da452').value = da21;
      document.getElementById('lc452').value = lc21;
         }
         if(design=="Branch Head" && city3 =="Amravati")
        {
    
          var tt21 = 3000;
          var da21 = (25/100) * tt21;
          var lc21 = (60/100) * tt21;
          var cc21 = (15/100) * tt21;
          // document.getElementById('cdac').value = da21;
          // document.getElementById('clc').value = lc21;
          // document.getElementById('ccc').value = cc21;
          document.getElementById('da452').value = da21;
         document.getElementById('lc452').value = lc21;
         }
         if(design=="Branch Head" && city3 =="Indore")
         {
   
           var tt21 = 3000;
           var da21 = (25/100) * tt21;
           var lc21 = (60/100) * tt21;
           var cc21 = (15/100) * tt21;
          //  document.getElementById('cdac').value = da21;
          //  document.getElementById('clc').value = lc21;
          //  document.getElementById('ccc').value = cc21;
           document.getElementById('da452').value = da21;
      document.getElementById('lc452').value = lc21;
          }
    
      if(design=="Officer"  && city3 =="Nagpur")
    {
    
      var tt22 = 2500;
      var da22 = (25/100) * tt22;
      var lc22 = (60/100) * tt22;
      var cc22 = (15/100) * tt22;
      // document.getElementById('cdac').value = da22;
      // document.getElementById('clc').value = lc22;
      // document.getElementById('ccc').value = cc22;
      document.getElementById('da452').value = da22;
      document.getElementById('lc452').value = lc22;
    }
    if(design=="Officer"  && city3 =="Nashik")
    {

      var tt22 = 2500;
      var da22 = (25/100) * tt22;
      var lc22 = (60/100) * tt22;
      var cc22 = (15/100) * tt22;
      // document.getElementById('cdac').value = da22;
      // document.getElementById('clc').value = lc22;
      // document.getElementById('ccc').value = cc22;
      document.getElementById('da452').value = da22;
      document.getElementById('lc452').value = lc22;
    }
    if(design=="Officer"  && city3 =="Aurangabad")
    {
     
      var tt22 = 2500;
      var da22 = (25/100) * tt22;
      var lc22 = (60/100) * tt22;
      var cc22 = (15/100) * tt22;
      // document.getElementById('cdac').value = da22;
      // document.getElementById('clc').value = lc22;
      // document.getElementById('ccc').value = cc22;
      document.getElementById('da452').value = da22;
      document.getElementById('lc452').value = lc22;
    }
    if(design=="Officer"  && city3 =="Nanded")
    {
    
      var tt22 = 2500;
      var da22 = (25/100) * tt22;
      var lc22 = (60/100) * tt22;
      var cc22 = (15/100) * tt22;
      // document.getElementById('cdac').value = da22;
      // document.getElementById('clc').value = lc22;
      // document.getElementById('ccc').value = cc22;
      document.getElementById('da452').value = da22
      document.getElementById('lc452').value = lc22;
    }
    if(design=="Officer"  && city3 =="Akola")
    {
   
      var tt22 = 2500;
      var da22 = (25/100) * tt22;
      var lc22 = (60/100) * tt22;
      var cc22 = (15/100) * tt22;
      // document.getElementById('cdac').value = da22;
      // document.getElementById('clc').value = lc22;
      // document.getElementById('ccc').value = cc22;
      document.getElementById('da452').value = da22;
      document.getElementById('lc452').value = lc22;
    }
    if(design=="Officer"  && city3 =="Amravati")
    {
   
      var tt22 = 2500;
      var da22 = (25/100) * tt22;
      var lc22 = (60/100) * tt22;
      var cc22 = (15/100) * tt22;
      // document.getElementById('cdac').value = da22;
      // document.getElementById('clc').value = lc22;
      // document.getElementById('ccc').value = cc22;
      document.getElementById('da452').value = da22;
      document.getElementById('lc452').value = lc22;
    }
    if(design=="Officer"  && city3 =="Indore")
    {
 
      var tt22 = 2500;
      var da22 = (25/100) * tt22;
      var lc22 = (60/100) * tt22;
      var cc22 = (15/100) * tt22;
      // document.getElementById('cdac').value = da22;
      // document.getElementById('clc').value = lc22;
      // document.getElementById('ccc').value = cc22;
      document.getElementById('da452').value = da22;
      document.getElementById('lc452').value = lc22;
    }
       if(design=="Executive"  && city3 =="Nagpur")
    {

      var tt23 = 2000;
      var da23 = (25/100) * tt23;
      var lc23 = (60/100) * tt23;
      var cc23 = (15/100) * tt23;
      // document.getElementById('cdac').value = da23;
      // document.getElementById('clc').value = lc23;
      // document.getElementById('ccc').value = cc23;
      document.getElementById('da452').value = da23;
      document.getElementById('lc452').value = lc23;
    }
    if(design=="Executive"  && city3 =="Nashik")
    {
 
      var tt23 = 2000;
      var da23 = (25/100) * tt23;
      var lc23 = (60/100) * tt23;
      var cc23 = (15/100) * tt23;
      // document.getElementById('cdac').value = da23;
      // document.getElementById('clc').value = lc23;
      // document.getElementById('ccc').value = cc23;
      document.getElementById('da452').value = da23;
      document.getElementById('lc452').value = lc23;
    }
    if(design=="Executive"  && city3 =="Aurangabad")
    {
  
      var tt23 = 2000;
      var da23 = (25/100) * tt23;
      var lc23 = (60/100) * tt23;
      var cc23 = (15/100) * tt23;
      // document.getElementById('cdac').value = da23;
      // document.getElementById('clc').value = lc23;
      // document.getElementById('ccc').value = cc23;
      document.getElementById('da452').value = da23;
      document.getElementById('lc452').value = lc23;
    }
    if(design=="Executive"  && city3 =="Nanded")
    {
     
      var tt23 = 2000;
      var da23 = (25/100) * tt23;
      var lc23 = (60/100) * tt23;
      var cc23 = (15/100) * tt23;
      // document.getElementById('cdac').value = da23;
      // document.getElementById('clc').value = lc23;
      // document.getElementById('ccc').value = cc23;
      document.getElementById('da452').value = da23;
      document.getElementById('lc452').value = lc23;
    }
    if(design=="Executive"  && city3 =="Akola")
    {
    
      var tt23 = 2000;
      var da23 = (25/100) * tt23;
      var lc23 = (60/100) * tt23;
      var cc23 = (15/100) * tt23;
      // document.getElementById('cdac').value = da23;
      // document.getElementById('clc').value = lc23;
      // document.getElementById('ccc').value = cc23;
      document.getElementById('da452').value = da23;
      document.getElementById('lc452').value = lc23;
    }
    if(design=="Executive"  && city3 =="Amravati")
    {
      
      var tt23 = 2000;
      var da23 = (25/100) * tt23;
      var lc23 = (60/100) * tt23;
      var cc23 = (15/100) * tt23;
      // document.getElementById('cdac').value = da23;
      // document.getElementById('clc').value = lc23;
      // document.getElementById('ccc').value = cc23;
      document.getElementById('da452').value = da23;
      document.getElementById('lc452').value = lc23;
    }
    if(design=="Executive"  && city3 =="Indore")
    {
  
      var tt23 = 2000;
      var da23 = (25/100) * tt23;
      var lc23 = (60/100) * tt23;
      var cc23 = (15/100) * tt23;
    //  document.getElementById('cdac').value = da23;
    //   document.getElementById('clc').value = lc23;
    //   document.getElementById('ccc').value = cc23;
      document.getElementById('da452').value = da23;
      document.getElementById('lc452').value = lc23;
    }
      if(design=="Messenger/Driver" && city3 =="Nagpur")
    {
      
      var tt24 = 1500;
      var da24 = (25/100) * tt24;
      var lc24 = (60/100) * tt24;
      var cc24 = (15/100) * tt24;
      // document.getElementById('cdac').value = da24;
      // document.getElementById('clc').value = lc24;
      // document.getElementById('ccc').value = cc24;
      document.getElementById('da452').value = da24;
      document.getElementById('lc452').value = lc24;
    }
    if(design=="Messenger/Driver" && city3 =="Nashik")
    {
 
      var tt24 = 1500;
      var da24 = (25/100) * tt24;
      var lc24 = (60/100) * tt24;
      var cc24 = (15/100) * tt24;
      // document.getElementById('cdac').value = da24;
      // document.getElementById('clc').value = lc24;
      // document.getElementById('ccc').value = cc24;
      document.getElementById('da452').value = da24;
      document.getElementById('lc452').value = lc24;
    }
    if(design=="Messenger/Driver" && city3 =="Aurangabad")
    {
      
      var tt24 = 1500;
      var da24 = (25/100) * tt24;
      var lc24 = (60/100) * tt24;
      var cc24 = (15/100) * tt24;
      // document.getElementById('cdac').value = da24;
      // document.getElementById('clc').value = lc24;
      // document.getElementById('ccc').value = cc24;
      document.getElementById('da452').value = da24;
      document.getElementById('lc452').value = lc24;
    }
    if(design=="Messenger/Driver" && city3 =="Nanded")
    {
      
      var tt24 = 1500;
      var da24 = (25/100) * tt24;
      var lc24 = (60/100) * tt24;
      var cc24 = (15/100) * tt24;
      // document.getElementById('cdac').value = da24;
      // document.getElementById('clc').value = lc24;
      // document.getElementById('ccc').value = cc24;
      document.getElementById('da452').value = da24;
      document.getElementById('lc452').value = lc24;
    }
    if(design=="Messenger/Driver" && city3 =="Akola")
    {
     
      var tt24 = 1500;
      var da24 = (25/100) * tt24;
      var lc24 = (60/100) * tt24;
      var cc24 = (15/100) * tt24;
      // document.getElementById('cdac').value = da24;
      // document.getElementById('clc').value = lc24;
      // document.getElementById('ccc').value = cc24;
      document.getElementById('da452').value = da24;
      document.getElementById('lc452').value = lc24;
    }
    if(design=="Messenger/Driver" && city3 =="Amravati")
    {
      
      var tt24 = 1500;
      var da24 = (25/100) * tt24;
      var lc24 = (60/100) * tt24;
      var cc24 = (15/100) * tt24;
      // document.getElementById('cdac').value = da24;
      // document.getElementById('clc').value = lc24;
      // document.getElementById('ccc').value = cc24;
      document.getElementById('da452').value = da24;
      document.getElementById('lc452').value = lc24;
    }
    if(design=="Messenger/Driver" && city3 =="Indore")
    {
    
      var tt24 = 1500;
      var da24 = (25/100) * tt24;
      var lc24 = (60/100) * tt24;
      var cc24 = (15/100) * tt24;
      // document.getElementById('cdac').value = da24;
      // document.getElementById('clc').value = lc24;
      // document.getElementById('ccc').value = cc24;
      document.getElementById('da452').value = da24;
      document.getElementById('lc452').value = lc24;
    }
    
    
  }

  


