<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel Bills System</title>
    <link rel="icon" href="fevicon.png"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet">
    <link href="../css/styles.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php
    include("header.php");
    include("../common/auth_session.php");
    require('../common/db.php');

    $username = $_SESSION['username'];
    ?>

    <main class="container-fluid px-4">
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="card-title">Travel Bills Details</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="datatablesSimple" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Sno.</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Branch</th>                                                           
                                <th>Application Date</th>
                                <th>Manager Approval</th>
                                <th>Admin Approval</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $ret = mysqli_query($con, "SELECT * FROM travel_data WHERE username='$username' ORDER BY tid DESC");
                            $cnt = 1;
                            while ($row = mysqli_fetch_array($ret)) {
                                ?>
                                <tr>
                                    <td><?php echo $cnt;?></td>
                                    <td><?php echo $row['first_name'];?></td>
                                    <td><?php echo $row['last_name'];?></td>
                                    <td><?php echo $row['branch'];?></td>                                                               
                                    <td><?php echo $row['application_date'];?></td>
                                    <td><?php echo $row['manager_approval'];?></td>
                                    <td><?php echo $row['admin_approval'];?></td>
                                    <td>
                                        <a href="user-profile.php?uid=<?php echo $row['tid'];?>" class="btn btn-info">View Details</a>
                                    </td>
                                </tr>
                                <?php
                                $cnt++;
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
    <script src="datatables-simple-demo.js"></script>
</body>
</html>
